# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, colorchooser
import datetime
from employee_management import EmployeeManagement

class SettingsWindow(tk.Toplevel):
    def __init__(self, master, emp_manager: EmployeeManagement):
        super().__init__(master)
        self.master = master
        self.emp_manager = emp_manager
        self.title("Ustawienia Systemu (Tylko dla Admina)")

        # Resizable + sensowne minimum (nie ucina przycisków)
        self.resizable(True, True)
        min_w, min_h = 900, 600
        self.minsize(min_w, min_h)

        # Rozmiar bazowy ~60%/75% okna głównego, wyśrodkowany względem master
        try:
            self.update_idletasks()
            mw = master.winfo_width() if master and hasattr(master, 'winfo_width') else 1200
            mh = master.winfo_height() if master and hasattr(master, 'winfo_height') else 800
            w = max(min_w, int(mw * 0.6))
            h = max(min_h, int(mh * 0.75))
            x = (master.winfo_rootx() + (mw - w) // 2) if master else 100
            y = (master.winfo_rooty() + (mh - h) // 2) if master else 100
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            self.geometry(f"{min_w}x{min_h}+100+100")

        self.transient(master)
        self.grab_set()

        # Styl
        self.style = ttk.Style(self)
        try:
            default_theme = self.emp_manager.get_setting('ui_theme')
        except Exception:
            default_theme = None

        # Nagłówek i Notebook
        header = ttk.Label(self, text="⚙️ Ustawienia systemu", font=('Segoe UI', 13, 'bold'))
        header.pack(anchor='w', padx=12, pady=(10, 4))

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=8)
        self.notebook.enable_traversal()

        # Zakładki
        self.create_general_settings_tab()
        self.create_shifts_tab()          # <- poprawiona zakładka Zmiany
        self.create_statuses_tab()
        self.create_user_management_tab()
        self.create_required_staff_tab()
        self.create_overflow_policy_tab()
        self.create_themes_tab()
        self.create_backup_tab()          # Backup/Import/Eksport

        # Odśwież dane + zastosuj zapamiętany motyw
        self.refresh_all_lists()
        try:
            theme_to_apply = default_theme or 'Systemowy'
            self.apply_theme(theme_to_apply, save=False)
            if hasattr(self, 'theme_combo'):
                self.theme_combo.set(theme_to_apply)
        except Exception:
            pass

    # ----------------- helpery -----------------
    def center_window(self):
        """Pozostawione dla zgodności – okno już jest pozycjonowane względem mastera."""
        try:
            self.update_idletasks()
            w = self.winfo_width()
            h = self.winfo_height()
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            x = (sw - w) // 2
            y = (sh - h) // 2
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

    # ----------------- Ogólne -----------------
    def create_general_settings_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        frame.pack_propagate(False)
        self.notebook.add(frame, text="Ogólne")

        # konfiguracje list (wydziały, stanowiska, maszyny)
        self.list_configs = {
            'Wydziały': {'key': 'wydzialy', 'listbox': None, 'entry': None},
            'Stanowiska': {'key': 'stanowiska', 'listbox': None, 'entry': None},
            'Maszyny/Urządzenia': {'key': 'maszyny', 'listbox': None, 'entry': None}
        }

        row_start = 0
        for title, config in self.list_configs.items():
            ttk.Label(frame, text=title, font=('Arial', 11, 'bold')).grid(
                row=row_start, column=0, columnspan=2, sticky="w", pady=(0, 6))

            config['listbox'] = tk.Listbox(frame, height=7)
            config['listbox'].grid(row=row_start + 1, column=0, columnspan=2,
                                   padx=5, pady=(0, 6), sticky="nsew")
            # Late-binding fix – przekazujemy LB i key
            config['listbox'].bind(
                '<Double-1>',
                lambda e, key=config['key'], lb=None: self.edit_general_item(key, e.widget)
            )

            config['entry'] = ttk.Entry(frame)
            config['entry'].grid(row=row_start + 2, column=0, padx=5, pady=(0, 6), sticky="ew")

            btn_frame = ttk.Frame(frame)
            btn_frame.grid(row=row_start + 2, column=1, padx=5, pady=(0, 6), sticky="w")

            ttk.Button(btn_frame, text="Dodaj",
                       command=lambda key=config['key'], lb=config['listbox'], entry=config['entry']:
                       self.add_general_item(key, lb, entry)).pack(side='left', padx=3)
            ttk.Button(btn_frame, text="Usuń",
                       command=lambda key=config['key'], lb=config['listbox']:
                       self.delete_general_item(key, lb)).pack(side='left', padx=3)
            ttk.Button(btn_frame, text="Edytuj",
                       command=lambda key=config['key'], lb=config['listbox']:
                       self.edit_general_item(key, lb)).pack(side='left', padx=3)

            row_start += 3

        ttk.Separator(frame, orient='horizontal').grid(row=row_start, column=0, columnspan=2, sticky='ew', pady=(4, 10))
        ttk.Button(frame, text="Wyczyść Listę Pracowników", command=self.clear_all_employees,
                   style='Accent.TButton').grid(row=row_start + 1, column=0, columnspan=2, pady=(0, 4), sticky='w')

        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=0)
        for r in range(row_start):
            frame.grid_rowconfigure(r, weight=0)
        frame.grid_rowconfigure(1, weight=1)

    # ----------------- Zmiany (POPRAWIONA) -----------------
    def create_shifts_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Zmiany")

        # Góra: lista zmian
        list_frame = ttk.LabelFrame(frame, text="Lista Zmian", padding="8")
        list_frame.pack(fill='both', expand=True)

        self.shifts_tree = ttk.Treeview(list_frame, columns=("Zmiana", "Start", "Koniec"),
                                        show="headings", height=8)
        self.shifts_tree.heading("#1", text="Zmiana")
        self.shifts_tree.heading("#2", text="Godzina rozpoczęcia")
        self.shifts_tree.heading("#3", text="Godzina zakończenia")
        self.shifts_tree.column("#1", width=260, stretch=False)
        self.shifts_tree.column("#2", width=160, stretch=False)
        self.shifts_tree.column("#3", width=160, stretch=False)

        v_scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.shifts_tree.yview)
        self.shifts_tree.configure(yscrollcommand=v_scroll.set)
        self.shifts_tree.pack(side='left', fill='both', expand=True)
        v_scroll.pack(side='right', fill='y')

        # Dół: formularz + szybkie panele WYŚRODKOWANE, a pod nimi przyciski WYŚRODKOWANE
        form_frame = ttk.LabelFrame(frame, text="Dodaj/Edytuj Zmianę", padding="10")
        form_frame.pack(fill='x', pady=(8, 0))

        # 1) Pola formularza (lewa część)
        fields = ttk.Frame(form_frame)
        fields.pack(fill='x', pady=(0, 6), anchor='w')

        ttk.Label(fields, text="Nazwa zmiany:").grid(row=0, column=0, padx=4, pady=4, sticky='w')
        self.shift_name_entry = ttk.Entry(fields, width=26)
        self.shift_name_entry.grid(row=0, column=1, padx=4, pady=4, sticky='w')

        ttk.Label(fields, text="Godzina rozpoczęcia:").grid(row=1, column=0, padx=4, pady=4, sticky='w')
        start_frame = ttk.Frame(fields)
        start_frame.grid(row=1, column=1, padx=4, pady=4, sticky='w')

        self.start_hour_var = tk.StringVar(value="06")
        self.start_minute_var = tk.StringVar(value="00")
        ttk.Combobox(start_frame, textvariable=self.start_hour_var,
                     values=[f"{i:02d}" for i in range(0, 24)],
                     width=3, state='readonly').pack(side='left')
        ttk.Label(start_frame, text=":").pack(side='left', padx=2)
        ttk.Combobox(start_frame, textvariable=self.start_minute_var,
                     values=[f"{i:02d}" for i in range(0, 60, 30)],
                     width=3, state='readonly').pack(side='left')

        ttk.Label(fields, text="Godzina zakończenia:").grid(row=2, column=0, padx=4, pady=4, sticky='w')
        end_frame = ttk.Frame(fields)
        end_frame.grid(row=2, column=1, padx=4, pady=4, sticky='w')

        self.end_hour_var = tk.StringVar(value="14")
        self.end_minute_var = tk.StringVar(value="00")
        ttk.Combobox(end_frame, textvariable=self.end_hour_var,
                     values=[f"{i:02d}" for i in range(0, 24)],
                     width=3, state='readonly').pack(side='left')
        ttk.Label(end_frame, text=":").pack(side='left', padx=2)
        ttk.Combobox(end_frame, textvariable=self.end_minute_var,
                     values=[f"{i:02d}" for i in range(0, 60, 30)],
                     width=3, state='readonly').pack(side='left')

        # Ukryte pole koloru – kompatybilność
        self.shift_color_entry = ttk.Entry(fields, width=10)
        self.shift_color_entry.insert(0, "#ADD8E6")
        self.shift_color_entry.grid(row=0, column=3, padx=4, pady=4, sticky='w')
        self.shift_color_entry.grid_remove()

        # 2) Szybkie panele – obok siebie, WYŚRODKOWANE
        quick_wrapper = ttk.Frame(form_frame)
        quick_wrapper.pack(fill='x', pady=(4, 6))
        quick_wrapper.grid_columnconfigure(0, weight=1)
        quick_wrapper.grid_columnconfigure(1, weight=0)
        quick_wrapper.grid_columnconfigure(2, weight=1)

        quick_container = ttk.Frame(quick_wrapper)
        quick_container.grid(row=0, column=1)  # środek

        quick_btn_frame = ttk.LabelFrame(quick_container, text="Szybkie ustawienia zmian", padding="6")
        quick_time_frame = ttk.LabelFrame(quick_container, text="Szybkie godziny", padding="6")

        # obok siebie, blisko
        quick_btn_frame.pack(side='left', padx=6)
        quick_time_frame.pack(side='left', padx=6)

        # Przyciski w szybkim panelu zmian
        ttk.Button(quick_btn_frame, text="A (6:00-14:00)",
                   command=lambda: self.set_quick_shift("A - Rano (6-14)", "06", "00", "14", "00", "#ADD8E6")).pack(fill='x', pady=2)
        ttk.Button(quick_btn_frame, text="B (14:00-22:00)",
                   command=lambda: self.set_quick_shift("B - Południe (14-22)", "14", "00", "22", "00", "#F08080")).pack(fill='x', pady=2)
        ttk.Button(quick_btn_frame, text="C (22:00-06:00)",
                   command=lambda: self.set_quick_shift("C - Noc (22-6)", "22", "00", "06", "00", "#20B2AA")).pack(fill='x', pady=2)
        ttk.Button(quick_btn_frame, text="D (Wolne)",
                   command=lambda: self.set_quick_shift("D - Wolne", "00", "00", "00", "00", "#90EE90")).pack(fill='x', pady=2)

        # Przyciski w szybkim panelu godzin
        ttk.Button(quick_time_frame, text="6:00-14:00",
                   command=lambda: self.set_quick_time("06", "00", "14", "00")).pack(fill='x', pady=2)
        ttk.Button(quick_time_frame, text="14:00-22:00",
                   command=lambda: self.set_quick_time("14", "00", "22", "00")).pack(fill='x', pady=2)
        ttk.Button(quick_time_frame, text="22:00-6:00",
                   command=lambda: self.set_quick_time("22", "00", "06", "00")).pack(fill='x', pady=2)
        ttk.Button(quick_time_frame, text="Wolne (0:00-0:00)",
                   command=lambda: self.set_quick_time("00", "00", "00", "00")).pack(fill='x', pady=2)

        # 3) Przyciski akcji – WYŚRODKOWANE pod szybkimi panelami
        button_row = ttk.Frame(form_frame)
        button_row.pack(fill='x', pady=(4, 0))
        # środek
        center_holder = ttk.Frame(button_row)
        center_holder.pack(anchor='center')

        ttk.Button(center_holder, text="Dodaj/Zapisz Zmianę",
                   command=self.add_edit_shift, style='Accent.TButton').pack(side='left', padx=6)
        ttk.Button(center_holder, text="Usuń Wybraną Zmianę",
                   command=self.delete_shift).pack(side='left', padx=6)
        ttk.Button(center_holder, text="Wyczyść Formularz",
                   command=self.clear_shift_form).pack(side='left', padx=6)

        self.shifts_tree.bind('<<TreeviewSelect>>', self.load_shift_data_to_entries)

    # ----------------- Polityka obsady -----------------
    def create_overflow_policy_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Polityka Obsady")

        ttk.Label(frame, text="Ustawienia zarządzania przekroczeniami obsady",
                  font=('Arial', 12, 'bold')).pack(pady=(0, 10), anchor='w')

        settings_frame = ttk.LabelFrame(frame, text="Polityka przekroczeń", padding="10")
        settings_frame.pack(fill='x')

        try:
            current_policy = self.emp_manager.get_overflow_policy()
        except Exception:
            current_policy = 'warning'
        self.policy_var = tk.StringVar(value=current_policy)

        ttk.Radiobutton(settings_frame, text="⚠️ Pokazuj ostrzeżenie",
                        variable=self.policy_var, value="warning").pack(anchor='w', pady=2)
        ttk.Radiobutton(settings_frame, text="Automatyczna korekta",
                        variable=self.policy_var, value="auto_adjust").pack(anchor='w', pady=2)
        ttk.Radiobutton(settings_frame, text="🔒 Blokada dodawania",
                        variable=self.policy_var, value="block").pack(anchor='w', pady=2)

        ttk.Button(settings_frame, text="Zapisz ustawienia",
                   command=self.save_overflow_policy, style='Accent.TButton').pack(anchor='w', pady=(8, 0))

        info_frame = ttk.LabelFrame(frame, text="Aktualne przekroczenia", padding="10")
        info_frame.pack(fill='both', expand=True, pady=(10, 0))

        self.overflow_tree = ttk.Treeview(info_frame, columns=("Wydział", "Zmiana", "Wymagana", "Aktualna", "Nadmiar"),
                                          show="headings", height=6)
        for i, txt in enumerate(("Wydział", "Zmiana", "Wymagana", "Aktualna", "Nadmiar"), start=1):
            self.overflow_tree.heading(f"#{i}", text=txt)
        self.overflow_tree.column("#1", width=160, stretch=False)
        self.overflow_tree.column("#2", width=160, stretch=False)
        self.overflow_tree.column("#3", width=90, stretch=False)
        self.overflow_tree.column("#4", width=90, stretch=False)
        self.overflow_tree.column("#5", width=90, stretch=False)
        self.overflow_tree.pack(fill='both', expand=True)

        action_frame = ttk.Frame(info_frame)
        action_frame.pack(fill='x', pady=(8, 0))
        ttk.Button(action_frame, text="Sprawdź przekroczenia",
                   command=self.show_current_overflows).pack(side='left', padx=5)
        ttk.Button(action_frame, text="Auto popraw",
                   command=self.auto_fix_overflows).pack(side='left', padx=5)
        ttk.Button(action_frame, text="Pokaż szczegóły",
                   command=self.show_overflow_details).pack(side='left', padx=5)

    def save_overflow_policy(self):
        policy = self.policy_var.get()
        try:
            self.emp_manager.save_overflow_policy(policy)
        except Exception:
            pass
        messagebox.showinfo("Sukces", f"Zapisano politykę: {policy}")

    def show_current_overflows(self):
        for i in self.overflow_tree.get_children():
            self.overflow_tree.delete(i)
        try:
            overflows = self.emp_manager.get_overflow_alerts() or []
        except Exception:
            overflows = []

        if not overflows:
            self.overflow_tree.insert("", tk.END, values=("Brak przekroczeń", "", "", "", ""))
            return

        for o in overflows:
            self.overflow_tree.insert("", tk.END, values=(
                o.get('wydzial', ''), o.get('zmiana', ''), o.get('wymagane', ''),
                o.get('aktualne', ''), o.get('nadmiar', '')
            ))

    def auto_fix_overflows(self):
        try:
            overflows = self.emp_manager.get_overflow_alerts() or []
        except Exception:
            overflows = []
        fixed = 0
        for o in overflows:
            try:
                moved = self.emp_manager.auto_adjust_overflow(o['wydzial'], o['zmiana'])
                if moved:
                    fixed += len(moved)
            except Exception:
                pass
        if fixed:
            messagebox.showinfo("Sukces", f"Przeniesiono {fixed} pracowników")
            self.show_current_overflows()
            if hasattr(self.master, 'refresh_employee_list'):
                self.master.refresh_employee_list()
        else:
            messagebox.showinfo("Info", "Brak przekroczeń do poprawienia")

    def show_overflow_details(self):
        try:
            overflows = self.emp_manager.get_overflow_alerts() or []
        except Exception:
            overflows = []
        if not overflows:
            messagebox.showinfo("Przekroczenia", "Brak aktualnych przekroczeń")
            return
        txt = "AKTUALNE PRZEKROCZENIA OBSADY:\n\n"
        for o in overflows:
            txt += f"• {o.get('wydzial','')} - {o.get('zmiana','')}: {o.get('aktualne','')}/{o.get('wymagane','')} (+{o.get('nadmiar','')})\n"
        messagebox.showinfo("Szczegóły", txt)

    # --- funkcje pomocnicze dla zmian ---
    def set_quick_shift(self, name, start_hour, start_minute, end_hour, end_minute, color):
        self.shift_name_entry.delete(0, tk.END)
        self.shift_name_entry.insert(0, name)
        self.start_hour_var.set(start_hour)
        self.start_minute_var.set(start_minute)
        self.end_hour_var.set(end_hour)
        self.end_minute_var.set(end_minute)
        self.shift_color_entry.delete(0, tk.END)
        self.shift_color_entry.insert(0, color)

    def set_quick_time(self, start_hour, start_minute, end_hour, end_minute):
        self.start_hour_var.set(start_hour)
        self.start_minute_var.set(start_minute)
        self.end_hour_var.set(end_hour)
        self.end_minute_var.set(end_minute)
        current_name = self.shift_name_entry.get()
        if " - " in current_name:
            base = current_name.split(" - ")[0]
            start_time = f"{start_hour}:{start_minute}"
            end_time = f"{end_hour}:{end_minute}"
            map_txt = {
                "06:00-14:00": "Rano (6-14)",
                "14:00-22:00": "Południe (14-22)",
                "22:00-06:00": "Noc (22-6)",
                "00:00-00:00": "Wolne"
            }
            key = f"{start_time}-{end_time}"
            suffix = map_txt.get(key, f"({start_time}-{end_time})")
            self.shift_name_entry.delete(0, tk.END)
            self.shift_name_entry.insert(0, f"{base} - {suffix}")

    def refresh_shifts_list(self):
        for i in self.shifts_tree.get_children():
            self.shifts_tree.delete(i)
        try:
            shifts = self.emp_manager.get_shifts_config() or []
        except Exception:
            shifts = []
        seen = set()
        for row in shifts:
            if len(row) >= 3:
                name, start, end = row[0], row[1], row[2]
                if name in seen:
                    continue
                seen.add(name)
                self.shifts_tree.insert("", tk.END, values=(name, start, end))

    def load_shift_data_to_entries(self, event):
        sel = self.shifts_tree.selection()
        if not sel:
            return
        values = self.shifts_tree.item(sel[0]).get('values', [])
        if len(values) < 3:
            return
        name, start, end = values[0], values[1], values[2]
        try:
            sh, sm = start.split(':')
            eh, em = end.split(':')
        except Exception:
            return
        self.shift_name_entry.delete(0, tk.END)
        self.shift_name_entry.insert(0, name)
        self.start_hour_var.set(sh)
        self.start_minute_var.set(sm)
        self.end_hour_var.set(eh)
        self.end_minute_var.set(em)
        try:
            color = self.emp_manager.get_shift_color(name)
        except Exception:
            color = "#ADD8E6"
        self.shift_color_entry.delete(0, tk.END)
        self.shift_color_entry.insert(0, color)

    def add_edit_shift(self):
        name = self.shift_name_entry.get().strip()
        start_time = f"{self.start_hour_var.get()}:{self.start_minute_var.get()}"
        end_time = f"{self.end_hour_var.get()}:{self.end_minute_var.get()}"
        color = self.shift_color_entry.get().strip()
        if not name or not color:
            messagebox.showerror("Błąd", "Nazwa i kolor zmiany są wymagane.")
            return
        try:
            datetime.datetime.strptime(start_time, '%H:%M')
            datetime.datetime.strptime(end_time, '%H:%M')
        except ValueError:
            messagebox.showerror("Błąd", "Nieprawidłowy format czasu.")
            return

        sel = self.shifts_tree.selection()
        is_edit = bool(sel)
        data = {'name': name, 'start_time': start_time, 'end_time': end_time, 'color': color}

        try:
            if is_edit:
                old_name = self.shifts_tree.item(sel[0])['values'][0]
                if self.emp_manager.delete_setting('shifts', old_name) and self.emp_manager.add_setting('shifts', data):
                    messagebox.showinfo("Sukces", f"Zmiana '{name}' zaktualizowana.")
                else:
                    # rollback symboliczny
                    self.emp_manager.add_setting('shifts', {'name': old_name, 'start_time': start_time,
                                                            'end_time': end_time, 'color': color})
                    messagebox.showerror("Błąd", "Nie udało się zaktualizować zmiany.")
            else:
                existing = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
                if name in existing:
                    messagebox.showerror("Błąd", f"Zmiana '{name}' już istnieje.")
                    return
                if self.emp_manager.add_setting('shifts', data):
                    messagebox.showinfo("Sukces", f"Dodano zmianę '{name}'.")
                else:
                    messagebox.showerror("Błąd", "Nie udało się dodać zmiany.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")

        self.refresh_shifts_list()
        if hasattr(self.master, 'update_dynamic_filters'):
            self.master.update_dynamic_filters()

    def delete_shift(self):
        sel = self.shifts_tree.selection()
        if not sel:
            messagebox.showerror("Błąd", "Wybierz zmianę do usunięcia.")
            return
        name = self.shifts_tree.item(sel[0])['values'][0]
        if not messagebox.askyesno("Potwierdzenie", f"Usunąć zmianę '{name}'?"):
            return
        try:
            if self.emp_manager.delete_setting('shifts', name):
                self.refresh_shifts_list()
                if hasattr(self.master, 'update_dynamic_filters'):
                    self.master.update_dynamic_filters()
            else:
                messagebox.showerror("Błąd", "Nie udało się usunąć zmiany.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")

    def clear_shift_form(self):
        self.shift_name_entry.delete(0, tk.END)
        self.start_hour_var.set("06")
        self.start_minute_var.set("00")
        self.end_hour_var.set("14")
        self.end_minute_var.set("00")
        self.shift_color_entry.delete(0, tk.END)
        self.shift_color_entry.insert(0, "#ADD8E6")
        for i in self.shifts_tree.selection():
            self.shifts_tree.selection_remove(i)

    # ------------- Statusy -------------
    def create_statuses_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Statusy")

        self.statuses_tree = ttk.Treeview(frame, columns=("Kolor",), show="tree", height=8)
        self.statuses_tree.heading("#0", text="Nazwa Statusu")
        self.statuses_tree.column("#0", width=220, stretch=False)
        self.statuses_tree.pack(fill='both', expand=True)

        entry_frame = ttk.LabelFrame(frame, text="Dodaj/Edytuj Status", padding="10")
        entry_frame.pack(fill='x', pady=(8, 0))

        ttk.Label(entry_frame, text="Nazwa statusu:").grid(row=0, column=0, padx=4, pady=4, sticky='w')
        self.status_name_entry = ttk.Entry(entry_frame, width=26)
        self.status_name_entry.grid(row=0, column=1, padx=4, pady=4, sticky='w')

        ttk.Label(entry_frame, text="Kolor:").grid(row=1, column=0, padx=4, pady=4, sticky='w')
        color_frame = ttk.Frame(entry_frame)
        color_frame.grid(row=1, column=1, padx=4, pady=4, sticky='w')

        self.status_color_entry = ttk.Entry(color_frame, width=10)
        self.status_color_entry.insert(0, "#3CB371")
        self.status_color_entry.grid(row=0, column=0, padx=(0, 6))
        ttk.Button(color_frame, text="Wybierz", command=self.choose_status_color).grid(row=0, column=1)
        self.color_preview = tk.Label(color_frame, text="   ", background="#3CB371",
                                      relief='solid', borderwidth=1, width=4)
        self.color_preview.grid(row=0, column=2, padx=6)

        quick = ttk.LabelFrame(entry_frame, text="Szybkie ustawienia", padding="6")
        quick.grid(row=0, column=2, rowspan=2, padx=10, pady=4, sticky='n')
        ttk.Button(quick, text="W Pracy", command=lambda: self.set_quick_status("W Pracy", "#3CB371")).pack(fill='x', pady=2)
        ttk.Button(quick, text="Urlop", command=lambda: self.set_quick_status("Urlop", "#FFA500")).pack(fill='x', pady=2)
        ttk.Button(quick, text="L4", command=lambda: self.set_quick_status("L4", "#FF4500")).pack(fill='x', pady=2)
        ttk.Button(quick, text="Wolne", command=lambda: self.set_quick_status("Wolne", "#98FB98")).pack(fill='x', pady=2)

        btn = ttk.Frame(entry_frame)
        btn.grid(row=2, column=0, columnspan=3, pady=(8, 0), sticky='w')
        ttk.Button(btn, text="Dodaj/Zapisz Status",
                   command=self.add_edit_status, style='Accent.TButton').pack(side='left', padx=6)
        ttk.Button(btn, text="Usuń Wybrany Status",
                   command=self.delete_status).pack(side='left', padx=6)

        self.statuses_tree.bind('<<TreeviewSelect>>', self.load_status_data_to_entries)

    def choose_status_color(self):
        try:
            color_code = self.status_color_entry.get()
            color = colorchooser.askcolor(initialcolor=color_code, title="Wybierz kolor statusu")
            if color and color[1]:
                self.status_color_entry.delete(0, tk.END)
                self.status_color_entry.insert(0, color[1])
                self.color_preview.config(background=color[1])
        except Exception as e:
            messagebox.showerror("Błąd", f"Nie udało się wybrać koloru: {e}")

    def set_quick_status(self, name, color):
        self.status_name_entry.delete(0, tk.END)
        self.status_name_entry.insert(0, name)
        self.status_color_entry.delete(0, tk.END)
        self.status_color_entry.insert(0, color)
        self.color_preview.config(background=color)

    def refresh_statuses_list(self):
        for i in self.statuses_tree.get_children():
            self.statuses_tree.delete(i)
        try:
            statuses = self.emp_manager.get_statuses_config() or []
        except Exception:
            statuses = []
        for name, color in statuses:
            self.statuses_tree.insert("", tk.END, text=name, values=(color,))

    def load_status_data_to_entries(self, event):
        sel = self.statuses_tree.selection()
        if not sel:
            return
        it = self.statuses_tree.item(sel[0])
        name = it['text']
        color = it['values'][0] if it['values'] else "#3CB371"
        self.status_name_entry.delete(0, tk.END)
        self.status_name_entry.insert(0, name)
        self.status_color_entry.delete(0, tk.END)
        self.status_color_entry.insert(0, color)
        self.color_preview.config(background=color)

    def add_edit_status(self):
        name = self.status_name_entry.get().strip()
        color = self.status_color_entry.get().strip()
        if not name or not color:
            messagebox.showerror("Błąd", "Nazwa i kolor statusu są wymagane.")
            return
        sel = self.statuses_tree.selection()
        is_edit = bool(sel)
        data = {'name': name, 'color': color}
        try:
            if is_edit:
                old_name = self.statuses_tree.item(sel[0])['text']
                if self.emp_manager.delete_setting('statuses', old_name) and self.emp_manager.add_setting('statuses', data):
                    messagebox.showinfo("Sukces", f"Status '{name}' zaktualizowany.")
                else:
                    self.emp_manager.add_setting('statuses', {'name': old_name, 'color': color})
                    messagebox.showerror("Błąd", "Nie udało się zaktualizować statusu.")
            else:
                if self.emp_manager.add_setting('statuses', data):
                    messagebox.showinfo("Sukces", f"Dodano status '{name}'.")
                else:
                    messagebox.showerror("Błąd", "Nie udało się dodać statusu.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")
        self.refresh_statuses_list()
        if hasattr(self.master, 'update_dynamic_filters'):
            self.master.update_dynamic_filters()

    def delete_status(self):
        sel = self.statuses_tree.selection()
        if not sel:
            messagebox.showerror("Błąd", "Wybierz status do usunięcia.")
            return
        name = self.statuses_tree.item(sel[0])['text']
        if not messagebox.askyesno("Potwierdzenie", f"Usunąć status '{name}'?"):
            return
        try:
            if self.emp_manager.delete_setting('statuses', name):
                self.refresh_statuses_list()
                if hasattr(self.master, 'update_dynamic_filters'):
                    self.master.update_dynamic_filters()
            else:
                messagebox.showerror("Błąd", "Nie udało się usunąć statusu.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")

    # ------------- Użytkownicy -------------
    def create_user_management_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Użytkownicy")

        self.users_tree = ttk.Treeview(frame, columns=("Rola",), show="tree", height=8)
        self.users_tree.heading("#0", text="Nazwa użytkownika")
        self.users_tree.column("#0", width=240, stretch=False)
        self.users_tree.pack(fill='both', expand=True)

        entry_frame = ttk.LabelFrame(frame, text="Dodaj/Edytuj Użytkownika", padding="10")
        entry_frame.pack(fill='x', pady=(8, 0))

        ttk.Label(entry_frame, text="Użytkownik:").grid(row=0, column=0, padx=4, pady=4, sticky='w')
        self.user_name_entry = ttk.Entry(entry_frame, width=26)
        self.user_name_entry.grid(row=0, column=1, padx=4, pady=4, sticky='w')

        ttk.Label(entry_frame, text="Hasło:").grid(row=1, column=0, padx=4, pady=4, sticky='w')
        self.user_password_entry = ttk.Entry(entry_frame, width=26, show="*")
        self.user_password_entry.grid(row=1, column=1, padx=4, pady=4, sticky='w')

        ttk.Label(entry_frame, text="Rola:").grid(row=2, column=0, padx=4, pady=4, sticky='w')
        self.user_role_var = tk.StringVar(value="operator")
        self.user_role_combo = ttk.Combobox(entry_frame, textvariable=self.user_role_var,
                                            values=['admin', 'manager', 'operator'],
                                            state='readonly', width=22)
        self.user_role_combo.grid(row=2, column=1, padx=4, pady=4, sticky='w')

        btn = ttk.Frame(entry_frame)
        btn.grid(row=3, column=0, columnspan=2, pady=(8, 0), sticky='w')
        ttk.Button(btn, text="Dodaj/Zapisz Użytkownika",
                   command=self.add_edit_user, style='Accent.TButton').pack(side='left', padx=6)
        ttk.Button(btn, text="Usuń Wybranego Użytkownika",
                   command=self.delete_user).pack(side='left', padx=6)

        self.users_tree.bind('<<TreeviewSelect>>', self.load_user_data_to_entries)

    def refresh_users_list(self):
        for i in self.users_tree.get_children():
            self.users_tree.delete(i)
        try:
            users = self.emp_manager.db.fetch_all("SELECT username, role FROM users")
        except Exception:
            users = []
        for username, role in users:
            self.users_tree.insert("", tk.END, text=username, values=(role,))

    def load_user_data_to_entries(self, event):
        sel = self.users_tree.selection()
        if not sel:
            return
        it = self.users_tree.item(sel[0])
        username = it['text']
        role = it['values'][0] if it['values'] else ''
        self.user_name_entry.delete(0, tk.END)
        self.user_name_entry.insert(0, username)
        self.user_role_var.set(role)
        self.user_password_entry.delete(0, tk.END)

    def add_edit_user(self):
        username = self.user_name_entry.get().strip()
        password = self.user_password_entry.get()
        role = self.user_role_var.get()
        if not username or not password or not role:
            messagebox.showerror("Błąd", "Wszystkie pola użytkownika są wymagane.")
            return
        data = {'username': username, 'password': password, 'role': role}
        try:
            if self.emp_manager.add_setting('users', data):
                messagebox.showinfo("Sukces", f"Zapisano użytkownika '{username}'.")
                self.refresh_users_list()
                self.user_name_entry.delete(0, tk.END)
                self.user_password_entry.delete(0, tk.END)
            else:
                messagebox.showerror("Błąd", "Nie udało się zapisać użytkownika.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")

    def delete_user(self):
        sel = self.users_tree.selection()
        if not sel:
            messagebox.showerror("Błąd", "Wybierz użytkownika do usunięcia.")
            return
        username = self.users_tree.item(sel[0])['text']
        if username == 'admin':
            messagebox.showerror("Błąd", "Nie można usunąć głównego administratora.")
            return
        if not messagebox.askyesno("Potwierdzenie", f"Usunąć użytkownika '{username}'?"):
            return
        try:
            if self.emp_manager.delete_setting('users', username):
                self.refresh_users_list()
            else:
                messagebox.showerror("Błąd", "Nie udało się usunąć użytkownika.")
        except Exception as e:
            messagebox.showerror("Błąd", f"Wystąpił błąd: {e}")

    # ------------- Wymagana obsada -------------
    def create_required_staff_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Wymagana Obsada")

        filter_frame = ttk.LabelFrame(frame, text="Filtry", padding="8")
        filter_frame.pack(fill='x')

        ttk.Label(filter_frame, text="Wydział:").grid(row=0, column=0, padx=4, pady=4, sticky='w')
        self.filter_wydzial_var = tk.StringVar()
        try:
            wydzialy_values = [''] + (self.emp_manager.get_setting('wydzialy') or [])
        except Exception:
            wydzialy_values = ['']
        self.filter_wydzial_combo = ttk.Combobox(filter_frame, textvariable=self.filter_wydzial_var,
                                                values=wydzialy_values, state='readonly', width=22)
        self.filter_wydzial_combo.grid(row=0, column=1, padx=4, pady=4, sticky='w')
        self.filter_wydzial_combo.bind('<<ComboboxSelected>>', self.apply_required_staff_filter)

        ttk.Label(filter_frame, text="Zmiana:").grid(row=0, column=2, padx=4, pady=4, sticky='w')
        self.filter_zmiana_var = tk.StringVar()
        try:
            zmiany_values = [''] + [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception:
            zmiany_values = ['']
        self.filter_zmiana_combo = ttk.Combobox(filter_frame, textvariable=self.filter_zmiana_var,
                                               values=zmiany_values, state='readonly', width=22)
        self.filter_zmiana_combo.grid(row=0, column=3, padx=4, pady=4, sticky='w')
        self.filter_zmiana_combo.bind('<<ComboboxSelected>>', self.apply_required_staff_filter)

        ttk.Button(filter_frame, text="Wyczyść Filtry",
                   command=self.clear_required_staff_filters).grid(row=0, column=4, padx=4, pady=4)

        filter_frame.columnconfigure(1, weight=1)
        filter_frame.columnconfigure(3, weight=1)

        ttk.Label(frame, text="Ustaw wymaganą liczbę pracowników na Wydziale i Zmianie",
                  font=('Arial', 11, 'bold')).pack(pady=(8, 6), anchor='w')

        self.required_staff_tree = ttk.Treeview(frame, columns=("Wydział", "Zmiana", "Wymagana Liczba"),
                                                show="headings", height=8)
        self.required_staff_tree.heading("#1", text="Wydział")
        self.required_staff_tree.heading("#2", text="Zmiana")
        self.required_staff_tree.heading("#3", text="Wymagana Liczba")
        self.required_staff_tree.column("#1", width=220, stretch=False)
        self.required_staff_tree.column("#2", width=220, stretch=False)
        self.required_staff_tree.column("#3", width=180, stretch=False)
        self.required_staff_tree.pack(fill='both', expand=True)

        entry_frame = ttk.LabelFrame(frame, text="Ustaw wymaganą obsadę", padding="10")
        entry_frame.pack(fill='x', pady=(8, 0))

        ttk.Label(entry_frame, text="Wydział:").grid(row=0, column=0, padx=4, pady=4, sticky='w')
        self.req_wydzial_var = tk.StringVar()
        try:
            req_wydzial_values = (self.emp_manager.get_setting('wydzialy') or [])
        except Exception:
            req_wydzial_values = []
        self.req_wydzial_combo = ttk.Combobox(entry_frame, textvariable=self.req_wydzial_var,
                                             values=req_wydzial_values, state='readonly', width=22)
        self.req_wydzial_combo.grid(row=0, column=1, padx=4, pady=4, sticky='w')

        ttk.Label(entry_frame, text="Zmiana:").grid(row=0, column=2, padx=4, pady=4, sticky='w')
        self.req_zmiana_var = tk.StringVar()
        try:
            req_zmiana_values = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception:
            req_zmiana_values = []
        self.req_zmiana_combo = ttk.Combobox(entry_frame, textvariable=self.req_zmiana_var,
                                             values=req_zmiana_values, state='readonly', width=22)
        self.req_zmiana_combo.grid(row=0, column=3, padx=4, pady=4, sticky='w')

        ttk.Label(entry_frame, text="Wymagana liczba:").grid(row=0, column=4, padx=4, pady=4, sticky='w')
        self.req_count_entry = ttk.Entry(entry_frame, width=10)
        self.req_count_entry.grid(row=0, column=5, padx=4, pady=4, sticky='w')

        btn = ttk.Frame(entry_frame)
        btn.grid(row=1, column=0, columnspan=6, pady=(8, 0), sticky='w')
        ttk.Button(btn, text="Ustaw",
                   command=self.save_required_staff, style='Accent.TButton').pack(side='left', padx=6)
        ttk.Button(btn, text="Wyczyść wszystkie",
                   command=self.clear_all_required_staff).pack(side='left', padx=6)

        self.required_staff_tree.bind('<<TreeviewSelect>>', self.load_required_staff_to_entries)

    def apply_required_staff_filter(self, event=None):
        for i in self.required_staff_tree.get_children():
            self.required_staff_tree.delete(i)
        try:
            wydzialy = (self.emp_manager.get_setting('wydzialy') or [])
        except Exception:
            wydzialy = []
        try:
            shifts = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception:
            shifts = []

        fw = self.filter_wydzial_var.get()
        fz = self.filter_zmiana_var.get()
        for w in wydzialy:
            for z in shifts:
                if fw and w != fw:
                    continue
                if fz and z != fz:
                    continue
                try:
                    count = self.emp_manager.get_required_staff_by_wydzial_shift(w, z)
                except Exception:
                    count = 0
                self.required_staff_tree.insert("", tk.END, values=(w, z, count))

    def clear_required_staff_filters(self):
        self.filter_wydzial_var.set('')
        self.filter_zmiana_var.set('')
        self.refresh_required_staff_list()

    def refresh_required_staff_list(self):
        for i in self.required_staff_tree.get_children():
            self.required_staff_tree.delete(i)
        try:
            wydzialy = (self.emp_manager.get_setting('wydzialy') or [])
        except Exception:
            wydzialy = []
        try:
            shifts = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception:
            shifts = []
        for w in wydzialy:
            for z in shifts:
                try:
                    count = self.emp_manager.get_required_staff_by_wydzial_shift(w, z)
                except Exception:
                    count = 0
                self.required_staff_tree.insert("", tk.END, values=(w, z, count))

    def load_required_staff_to_entries(self, event):
        sel = self.required_staff_tree.selection()
        if not sel:
            return
        w, z, count = self.required_staff_tree.item(sel[0])['values']
        self.req_wydzial_var.set(w)
        self.req_zmiana_var.set(z)
        self.req_count_entry.delete(0, tk.END)
        self.req_count_entry.insert(0, count)

    def save_required_staff(self):
        w = self.req_wydzial_var.get()
        z = self.req_zmiana_var.get()
        s = self.req_count_entry.get().strip()
        try:
            c = int(s)
            if c < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Błąd", "Wymagana liczba musi być nieujemną liczbą całkowitą.")
            return
        if not w or not z:
            messagebox.showerror("Błąd", "Wybierz Wydział i Zmianę.")
            return
        try:
            self.emp_manager.save_required_staff(w, z, c)
        except Exception:
            pass
        messagebox.showinfo("Sukces", f"Ustawiono wymaganą obsadę: {w} / {z} = {c}")
        self.refresh_required_staff_list()
        if hasattr(self.master, 'update_dashboard'):
            self.master.update_dashboard()

    def clear_all_required_staff(self):
        if not messagebox.askyesno("Potwierdzenie", "Wyczyścić wszystkie ustawienia wymaganej obsady?"):
            return
        try:
            wydzialy = (self.emp_manager.get_setting('wydzialy') or [])
        except Exception:
            wydzialy = []
        try:
            shifts = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception:
            shifts = []
        for w in wydzialy:
            for z in shifts:
                try:
                    self.emp_manager.save_required_staff(w, z, 0)
                except Exception:
                    pass
        self.refresh_required_staff_list()
        messagebox.showinfo("Sukces", "Wyczyszczono wszystkie ustawienia wymaganej obsady.")

    # ------------- General settings helpers -------------
    def refresh_general_list(self, key):
        try:
            config = [c for c in self.list_configs.values() if c['key'] == key][0]
        except Exception:
            return
        try:
            data = self.emp_manager.get_setting(key) or []
        except Exception:
            data = []
        config['listbox'].delete(0, tk.END)
        for item in data:
            config['listbox'].insert(tk.END, item)

    def add_general_item(self, key, listbox, entry):
        name = entry.get().strip()
        if not name:
            messagebox.showerror("Błąd", "Wpis nie może być pusty.")
            return
        try:
            data = self.emp_manager.get_setting(key) or []
        except Exception:
            data = []
        if name in data:
            messagebox.showerror("Błąd", f"Wpis '{name}' już istnieje.")
            return
        data.append(name)
        try:
            self.emp_manager.save_setting(key, data)
        except Exception:
            pass
        self.refresh_general_list(key)
        entry.delete(0, tk.END)
        if hasattr(self.master, 'update_dynamic_filters'):
            self.master.update_dynamic_filters()

    def delete_general_item(self, key, listbox):
        sel = listbox.curselection()
        if not sel:
            messagebox.showerror("Błąd", "Wybierz element do usunięcia.")
            return
        name = listbox.get(sel[0])
        if not messagebox.askyesno("Potwierdzenie", f"Usunąć '{name}'?"):
            return
        try:
            self.emp_manager.delete_setting(key, name)
        except Exception:
            pass
        self.refresh_general_list(key)
        if hasattr(self.master, 'update_dynamic_filters'):
            self.master.update_dynamic_filters()

    def edit_general_item(self, key, listbox):
        sel = listbox.curselection()
        if not sel:
            messagebox.showerror("Błąd", "Wybierz element do edycji.")
            return
        old_name = listbox.get(sel[0])
        new_name = simpledialog.askstring("Edycja", f"Edytuj '{old_name}':", initialvalue=old_name, parent=self)
        if not new_name or new_name == old_name:
            return
        try:
            data = self.emp_manager.get_setting(key) or []
        except Exception:
            data = []
        if new_name in data:
            messagebox.showerror("Błąd", f"Wpis '{new_name}' już istnieje.")
            return
        try:
            data.remove(old_name)
        except ValueError:
            pass
        data.append(new_name)
        try:
            self.emp_manager.save_setting(key, data)
        except Exception:
            pass
        self.refresh_general_list(key)
        if hasattr(self.master, 'update_dynamic_filters'):
            self.master.update_dynamic_filters()

    def clear_all_employees(self):
        if not messagebox.askyesno("Potwierdzenie", "Usunąć WSZYSTKICH pracowników? Tej operacji nie można cofnąć!"):
            return
        try:
            self.emp_manager.db.execute_query("DELETE FROM employees")
            self.emp_manager.log_history("Czyszczenie Bazy", "Usunięto wszystkich pracowników.")
            messagebox.showinfo("Sukces", "Wszyscy pracownicy zostali usunięci.")
            if hasattr(self.master, 'refresh_employee_list'):
                self.master.refresh_employee_list()
        except Exception as e:
            messagebox.showerror("Błąd", f"Nie udało się usunąć pracowników: {e}")

    def refresh_all_lists(self):
        try:
            for key in self.list_configs:
                self.refresh_general_list(self.list_configs[key]['key'])
        except Exception:
            pass
        try: self.refresh_shifts_list()
        except Exception: pass
        try: self.refresh_statuses_list()
        except Exception: pass
        try: self.refresh_users_list()
        except Exception: pass
        try: self.refresh_required_staff_list()
        except Exception: pass

        # Uzupełnij wartości comboboxów (gdy zmieniły się ustawienia)
        try: self.req_wydzial_combo['values'] = (self.emp_manager.get_setting('wydzialy') or [])
        except Exception: pass
        try: self.req_zmiana_combo['values'] = [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception: pass
        try: self.filter_wydzial_combo['values'] = [''] + (self.emp_manager.get_setting('wydzialy') or [])
        except Exception: pass
        try: self.filter_zmiana_combo['values'] = [''] + [s[0] for s in (self.emp_manager.get_shifts_config() or [])]
        except Exception: pass

    # ------------- Motywy -------------
    def create_themes_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Motywy")

        ttk.Label(frame, text="Wybierz motyw aplikacji:", font=('Arial', 11)).pack(anchor='w', pady=(0, 6))
        themes = ['Systemowy', 'Jasny', 'Ciemny', 'Azure', 'Sun Valley']
        self.theme_var = tk.StringVar(value='Systemowy')
        self.theme_combo = ttk.Combobox(frame, textvariable=self.theme_var, values=themes,
                                        state='readonly', width=24)
        self.theme_combo.pack(anchor='w', padx=4, pady=(0, 8))

        btn = ttk.Frame(frame)
        btn.pack(anchor='w', pady=(0, 6))
        ttk.Button(btn, text="Zastosuj motyw",
                   command=self.on_theme_apply, style='Accent.TButton').pack(side='left', padx=4)
        ttk.Button(btn, text="Przywróć domyślny",
                   command=self.on_theme_reset).pack(side='left', padx=4)

        self.theme_preview = ttk.Label(frame, text="Motyw zmieni się natychmiast po naciśnięciu Zastosuj.",
                                       foreground='gray')
        self.theme_preview.pack(anchor='w', padx=4)

    def on_theme_apply(self):
        self.apply_theme(self.theme_var.get(), save=True)

    def on_theme_reset(self):
        self.theme_combo.set('Systemowy')
        self.apply_theme('Systemowy', save=True)

    def apply_theme(self, theme_name, save=True):
        try:
            if theme_name == 'Sun Valley':
                try:
                    self.tk.call('source', 'sun-valley.tcl')
                    self.style.theme_use('sun-valley')
                except Exception:
                    self.style.theme_use('clam')
                    self.style.configure('.', background='#F7F9FB', foreground='#111111')
            elif theme_name == 'Azure':
                try:
                    self.tk.call('source', 'azure.tcl')
                    self.style.theme_use('azure')
                except Exception:
                    self.style.theme_use('clam')
                    self.style.configure('.', background='#F0F6FF', foreground='#0B3D91')
            elif theme_name == 'Jasny':
                self.style.theme_use('clam')
                self.style.configure('.', background='#FFFFFF', foreground='#111111')
                self.configure(bg='#FFFFFF')
            elif theme_name == 'Ciemny':
                self.style.theme_use('clam')
                self.style.configure('.', background='#2E2E2E', foreground='#EDEDED')
                self.style.configure('TLabel', background='#2E2E2E', foreground='#EDEDED')
                self.style.configure('TFrame', background='#2E2E2E')
                self.configure(bg='#2E2E2E')
            else:
                pass

            try:
                if hasattr(self.master, 'change_theme') and theme_name in ['Jasny', 'Ciemny', 'Azure', 'Sun Valley']:
                    mapping = {'Jasny': 'light', 'Ciemny': 'dark', 'Azure': 'blue', 'Sun Valley': 'modern'}
                    mapped = mapping.get(theme_name)
                    if mapped:
                        self.master.change_theme(mapped)
                        if hasattr(self.master, 'theme_var'):
                            self.master.theme_var.set(mapped)
            except Exception:
                pass

            if save:
                try:
                    self.emp_manager.save_setting('ui_theme', theme_name)
                except Exception:
                    pass

            try:
                self.update_idletasks()
                self.theme_preview.config(text=f"Zastosowano motyw: {theme_name}")
            except Exception:
                pass

        except Exception as e:
            messagebox.showerror("Błąd", f"Nie udało się zastosować motywu: {e}")

    # ------------- Backup / Import / Eksport -------------
    def create_backup_tab(self):
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Backup")

        ttk.Label(frame, text="Operacje na danych", font=('Arial', 11, 'bold')).pack(anchor='w', pady=(0, 8))

        btns = ttk.Frame(frame)
        btns.pack(anchor='w', pady=2)

        ttk.Button(btns, text="💾 Utwórz backup",
                   command=self._do_backup, style='Accent.TButton').pack(side='left', padx=4)
        ttk.Button(btns, text="⬆️ Eksport do Excel",
                   command=self._do_export).pack(side='left', padx=4)
        ttk.Button(btns, text="⬇️ Import z Excel",
                   command=self._do_import).pack(side='left', padx=4)

        ttk.Label(frame, text="Uwaga: import dodaje pracowników wg reguł importu; eksport tworzy plik XLSX.",
                  foreground='gray').pack(anchor='w', pady=(10, 0))

    def _do_backup(self):
        try:
            if hasattr(self.master, 'create_backup'):
                self.master.create_backup()
            elif hasattr(self.emp_manager, 'db') and hasattr(self.emp_manager.db, 'backup_database'):
                backup_file = self.emp_manager.db.backup_database()
                if backup_file:
                    messagebox.showinfo('Backup', f'Utworzono backup:\n{backup_file}')
                else:
                    messagebox.showerror('Backup', 'Nie udało się utworzyć backupu.')
            else:
                messagebox.showerror('Backup', 'Brak funkcji tworzenia backupu.')
        except Exception as e:
            messagebox.showerror('Backup', f'Błąd: {e}')

    def _do_export(self):
        try:
            if hasattr(self.master, 'export_to_excel'):
                self.master.export_to_excel()
            else:
                messagebox.showerror("Eksport", "Brak funkcji eksportu w oknie głównym.")
        except Exception as e:
            messagebox.showerror("Eksport", f"Błąd eksportu: {e}")

    def _do_import(self):
        try:
            if hasattr(self.master, 'import_employees_from_excel'):
                self.master.import_employees_from_excel()
            else:
                messagebox.showerror("Import", "Brak funkcji importu w oknie głównym.")
        except Exception as e:
            messagebox.showerror("Import", f"Błąd importu: {e}")