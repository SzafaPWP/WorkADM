README - WorkADM installer package
---------------------------------

Files:
- workadm_launcher.py        : launcher script that runs your real Python program
- WorkADM.ico                : icon for the EXE (if provided)
- build_workadm_onedir.bat   : builds launcher as onedir (recommended for testing)
- build_workadm_no_upx.bat   : builds onefile without UPX (recommended if onefile desired)
- installer.nsi              : NSIS installer script (expects dist\WorkADM.exe and LICENSE.txt)
- build_installer.bat        : runs makensis to create WorkADM_Installer.exe
- LICENSE.txt (optional)     : put your license file here to be included in installer

How to create EXE and installer:
1. Place WorkADM.ico and workadm_launcher.py in a folder.
2. Install PyInstaller: pip install pyinstaller
3. Run build_workadm_onedir.bat to produce dist\WorkADM\WorkADM.exe (recommended)
   or build_workadm_no_upx.bat to produce single EXE dist\WorkADM.exe
4. Copy the produced EXE to this folder as dist\WorkADM.exe (if building elsewhere).
5. Put your LICENSE.txt file next to installer.nsi (this will be shown at install).
6. Install NSIS (https://nsis.sourceforge.io/) and ensure makensis is on PATH.
7. Run build_installer.bat to create WorkADM_Installer.exe.

Notes:
- The installer copies only the launcher EXE. Your real program should remain in:
  C:\Users\SZAFA\Desktop\WorkADM\nowyprojekt\testowy
  The launcher will open that folder's main_window.py.
- If you prefer to bundle the whole project into the installer, edit installer.nsi and
  uncomment the File /r "project\*.*" line and adjust path.

